struct  CarEngine {
    var V4Eng = 147
    var V6Eng = 235
    var V8Eng = 324
}
let myCarEngine = CarEngine()

print("The price of the V4 Engine is $\(myCarEngine.V4Eng).")
print("The price of the V6 Engine is $\(myCarEngine.V6Eng).")
print("The price of the V8 Engine is $\(myCarEngine.V8Eng).")
